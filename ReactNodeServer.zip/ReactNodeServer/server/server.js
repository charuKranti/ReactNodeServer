const express = require("express");
const server = express();
var endPoints = require('./restAPIrouter');
const port = 4200;
var inContainer = process.env.CONTAINER
server.use('', endPoints);
//The build folder has our static resources (index.html, css, images)
// redirect all others to the index (HTML5 history)
server.all('/', function(req, res) {
    res.send('Server');
});
server.listen(port,()=>console.log("Server is turned ON! "));