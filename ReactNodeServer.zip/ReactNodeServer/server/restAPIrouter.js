const express = require('express');
const router = express.Router();
router.use(function (req, res, next) {
    // For cors or cross orgin fix.
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, cache-control, x-powered-by, access-control-allow-origin, bpm_generic_header, content-language, Content-Type, Accept, Authorization");
    next()
});

var data = {
	"status": "200",
	"data": {
		"identifier": "TASK.TKIID",
		"query": "NB_ClaimedAndAvailable",
		"entityTypeName": "TASK",
		"queryExecuteTime": "2021-05-24T07:23:30Z",
		"taskIndexUpdateInterval": 5,
		"offset": 0,
		"size": 3,
		"requestedSize": 10000,
		"totalCount": 3,
		"countLimitExceeded": false,
		"countLimit": 500,
		"lowPriorityCnt": 1,
		"midPriorityCnt": 1,
		"highPriorityCnt": 1,
		"attributeInfo": [{
			"name": "suspenseAmount",
			"type": "string",
			"content": "TASK.BDSUSPENSE_AMOUNT",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.suspenseAmount",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Suspense Amount",
			"columnRequired": true,
			"order":10
		}, {
			"name": "policyNumber",
			"type": "string",
			"content": "TASK.BDPOLICY_NUMBER",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.policyNumber",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Policy Number",
			"columnRequired": true,
			"order":1
		}, {
			"name": "suspendedFlagUW",
			"type": "BOOLEAN",
			"content": "TASK.BDPARKED_CASE_FLAG_U_W",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.parkedCaseFlagUW",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "suspendedFlagUW",
			"columnRequired": false,
			"order":11
		}, {
			"name": "savedAsDraftUW",
			"type": "BOOLEAN",
			"content": "TASK.BDSAVED_AS_DRAFT_U_W",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.savedAsDraftUW",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "savedAsDraftUW",
			"columnRequired": false,
			"order":12
		}, {
			"name": "planName",
			"type": "string",
			"content": "TASK.BDPLAN_NAME",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.planName",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Plan Name",
			"columnRequired": false,
			"order":13
		}, {
			"name": "flaggedAML",
			"type": "BOOLEAN",
			"content": "TASK.BDFLAGGED_A_M_L",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.flaggedAML",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "flaggedAML",
			"columnRequired": false,
			"order":14
		}, {
			"name": "displayName",
			"type": "string",
			"content": "TASK.BDWORKFLOW_STATUS",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.workflowStatus",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Workflow Status",
			"columnRequired": false,
			"order":15
		}, {
			"name": "planCode",
			"type": "string",
			"content": "TASK.BDPLAN_CODE",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.planCode",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Plan Code",
			"columnRequired": true,
			"order":5
		}, {
			"name": "owner",
			"type": "string",
			"content": "TASK.OWNER",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.assignedToUser",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Current User",
			"columnRequired": true,
			"order":16
		}, {
			"name": "paymentMethod",
			"type": "string",
			"content": "TASK.BDPAYMENT_METHOD",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.paymentMethod",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Payment Method",
			"columnRequired": false,
			"order":17
		}, {
			"name": "channel",
			"type": "string",
			"content": "TASK.BDCHANNEL",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.channel",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Channel",
			"columnRequired": true,
			"order":6
		}, {
			"name": "priority",
			"type": "NUMBER",
			"content": "TASK.PRIORITY",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.taskPriority",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Priority",
			"columnRequired": false,
			"order":18
		}, {
			"name": "freshCase",
			"type": "string",
			"content": "TASK.BDFRESH_O_RR2_O_RCS_CASE",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.freshORr2ORcsCase",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Fresh Case",
			"columnRequired": true,
			"order":4
		}, {
			"name": "ape",
			"type": "string",
			"content": "TASK.BD_A_P_E",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.APE",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "APE",
			"columnRequired": true,
			"order":9
		}, {
			"name": "receivedDate",
			"type": "TIMESTAMP",
			"content": "TASK.ACTIVATED",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.taskReceivedDate",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Received Date / Time",
			"columnRequired": true,
			"order":19
		}, {
			"name": "planType",
			"type": "string",
			"content": "TASK.BDPLAN_TYPE",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.planType",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Plan type",
			"columnRequired": true,
			"order":20
		}, {
			"name": "due",
			"type": "TIMESTAMP",
			"content": "TASK.DUE",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.taskDueDate",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Task Due Date",
			"columnRequired": false,
			"order":21
		}, {
			"name": "flaggedUW",
			"type": "BOOLEAN",
			"content": "TASK.BDFLAGGED_U_W",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.flaggedUW",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "flaggedUW",
			"columnRequired": false,
			"order":22
		}, {
			"name": "savedAsDraftAML",
			"type": "BOOLEAN",
			"content": "TASK.BDSAVED_AS_DRAFT_A_M_L",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.savedAsDraftAML",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "savedAsDraftAML",
			"columnRequired": false,
			"order":23
		}, {
			"name": "premiumIndicator",
			"type": "string",
			"content": "TASK.BDPREMIUM_INDICATOR",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.premiumIndicator",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Premium Indicator",
			"columnRequired": true,
			"order":24
		}, {
			"name": "tsar",
			"type": "string",
			"content": "TASK.BD_T_S_A_R",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.TSAR",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "TSAR",
			"columnRequired": true,
			"order":8
		}, {
			"name": "suspendedFlagAML",
			"type": "BOOLEAN",
			"content": "TASK.BDPARKED_CASE_FLAG_A_M_L",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.parkedCaseFlagAML",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "suspendedFlagAML",
			"columnRequired": false,
			"order":25
		}, {
			"name": "activityName",
			"type": "string",
			"content": "TASK_DESC.DISPLAY_NAME",
			"isArray": false,
			"sourceAttribute": "NB_ClaimedAndAvailable.taskSubject",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Activity Name",
			"columnRequired": true,
			"order":3
		}, {
			"name": "task",
			"type": "string",
			"content": "task",
			"isArray": false,
			"sourceAttribute": "task",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Task",
			"columnRequired": true,
			"order":26
		}, {
			"name": "planName",
			"type": "string",
			"content": "planName",
			"isArray": false,
			"sourceAttribute": "planName",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "Plan Name",
			"columnRequired": false,
			"order":27
		}, {
			"name": "activityStartDate",
			"type": "TIMESTAMP",
			"content": "activityStartDate",
			"isArray": false,
			"sourceAttribute": "activityStartDate",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": false,
			"field": "Activity Start Date/Time",
			"columnRequired": true,
			"order":2
		}, {
			"name": "uwDecision",
			"type": "string",
			"content": "uwDecision",
			"isArray": false,
			"sourceAttribute": "uwDecision",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "UW Decision ",
			"columnRequired": true,
			"order":7
		}, {
			"name": "concurrentPolicyFlag",
			"type": "BOOLEAN",
			"content": "concurrentPolicyFlag",
			"isArray": false,
			"sourceAttribute": "concurrentPolicyFlag",
			"sourceQueryTableIdentifier": "n/a",
			"hidden": true,
			"field": "concurrentPolicyFlag",
			"columnRequired": false,
			"order":28
		}],
		"items": [{
			"policyNumber": "'11111111'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": true,
			"due": "2020-10-18T08:23:36Z",
			"priority": 20,
			"remark": null,
			"suspendedFlagUW": true,
			"suspendedFlagAML": false,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"task": "l10001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":true,
			"savedAsDraftAML":false
		}, {
			"policyNumber": "'11111112'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 20,
			"remark": null,
			"suspendedFlagUW": true,
			"suspendedFlagAML": false,
			"task": "null10001",
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"concurrentPolicyFlag": null,
			"savedAsDraftUW":true,
			"savedAsDraftAML":false
		}, {
			"policyNumber": "'11111113'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 40,
			"remark": null,
			"suspendedFlagUW": true,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"suspendedFlagAML": false,
			"task": "Cha001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":true,
			"savedAsDraftAML":false
		}, {
			"policyNumber": "'11111113'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 40,
			"remark": null,
			"suspendedFlagUW": true,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"suspendedFlagAML": false,
			"task": "Cha001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":false,
			"savedAsDraftAML":false
		}, {
			"policyNumber": "'11111113'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 40,
			"remark": null,
			"suspendedFlagUW": true,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"suspendedFlagAML": false,
			"task": "Cha001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":false,
			"savedAsDraftAML":true
		}, {
			"policyNumber": "'11111113'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 40,
			"remark": null,
			"suspendedFlagUW": true,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"suspendedFlagAML": false,
			"task": "Cha001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":false,
			"savedAsDraftAML":true
		}, {
			"policyNumber": "'11111113'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 40,
			"remark": null,
			"suspendedFlagUW": true,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"suspendedFlagAML": false,
			"task": "Cha001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":false,
			"savedAsDraftAML":false
		}, {
			"policyNumber": "'11111113'",
			"activityStartDate": "2021-05-20T10:01:15Z",
			"activityName": "Step: Non Med Task",
			"freshCase": "Fresh",
			"planCode": "planCode1",
			"channel": "Channel1",
			"uwDecision": null,
			"tsar": "10001",
			"ape": "APE1",
			"suspenseAmount": "100",
			"planType": "PlanType1",
			"owner": "NonMedUW1",
			"premiumIndicator": "N",
			"receivedDate": "2021-05-20T10:01:15Z",
			"instanceId": "3139",
			"taskId": "3312",
			"planName": "PlanName",
			"displayName": null,
			"savedAsDraftUW": false,
			"savedAsDraftAML": false,
			"flaggedAML": false,
			"paymentMethod": "paymentMethod1",
			"flaggedUW": false,
			"due": "2020-10-18T08:23:36Z",
			"priority": 40,
			"remark": null,
			"suspendedFlagUW": true,
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,
			"suspendedFlagAML": false,
			"task": "Cha001",
			"concurrentPolicyFlag": true,
			"savedAsDraftUW":false,
			"savedAsDraftAML":false
		}]
	}
};

router.get('/api/tasklist/NB_ClaimedAndAvailable', function (req, res) {
    if(req.query && req.query.searchFilter) {
        return res.status(200).send(data)
    }
    else if(req.query && req.query.searchFilter) {

    }else {
        return res.status(200).send(data);
    }
});
router.get('/api/tasklist/prioritylist/:id', function (req, res) {
    if(req.params.id == 20) {
// high
        var data20 = {"status":"200","data":{"identifier":"TASK.TKIID","query":"NB_ClaimedAndAvailable","entityTypeName":"TASK","queryExecuteTime":"2021-05-24T07:23:30Z","taskIndexUpdateInterval":5,"offset":0,"size":3,"requestedSize":10000,"totalCount":3,"countLimitExceeded":false,"countLimit":500,"lowPriorityCnt":1,"midPriorityCnt":1,"highPriorityCnt":1,"attributeInfo":[{"name":"suspenseAmount","type":"string","content":"TASK.BDSUSPENSE_AMOUNT","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.suspenseAmount","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Suspense Amount","columnRequired":true},{"name":"policyNumber","type":"string","content":"TASK.BDPOLICY_NUMBER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.policyNumber","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Policy Number","columnRequired":true},{"name":"suspendedFlagUW","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagUW","columnRequired":false},{"name":"savedAsDraftUW","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftUW","columnRequired":false},{"name":"planName","type":"string","content":"TASK.BDPLAN_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"flaggedAML","type":"BOOLEAN","content":"TASK.BDFLAGGED_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedAML","columnRequired":false},{"name":"displayName","type":"string","content":"TASK.BDWORKFLOW_STATUS","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.workflowStatus","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Workflow Status","columnRequired":false},{"name":"planCode","type":"string","content":"TASK.BDPLAN_CODE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planCode","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Plan Code","columnRequired":true},{"name":"owner","type":"string","content":"TASK.OWNER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.assignedToUser","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Current User","columnRequired":true},{"name":"paymentMethod","type":"string","content":"TASK.BDPAYMENT_METHOD","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.paymentMethod","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Payment Method","columnRequired":false},{"name":"channel","type":"string","content":"TASK.BDCHANNEL","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.channel","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Channel","columnRequired":true},{"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskPriority","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Priority","columnRequired":false},{"name":"freshCase","type":"string","content":"TASK.BDFRESH_O_RR2_O_RCS_CASE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.freshORr2ORcsCase","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Fresh or R2 or c/s cases","columnRequired":true},{"name":"ape","type":"string","content":"TASK.BD_A_P_E","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.APE","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"APE","columnRequired":true},{"name":"receivedDate","type":"TIMESTAMP","content":"TASK.ACTIVATED","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskReceivedDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Received Date / Time","columnRequired":true},{"name":"planType","type":"string","content":"TASK.BDPLAN_TYPE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planType","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan type","columnRequired":true},{"name":"due","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskDueDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Task Due Date","columnRequired":false},{"name":"flaggedUW","type":"BOOLEAN","content":"TASK.BDFLAGGED_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedUW","columnRequired":false},{"name":"savedAsDraftAML","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftAML","columnRequired":false},{"name":"premiumIndicator","type":"string","content":"TASK.BDPREMIUM_INDICATOR","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.premiumIndicator","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Premium Indicator","columnRequired":true},{"name":"tsar","type":"string","content":"TASK.BD_T_S_A_R","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.TSAR","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"TSAR","columnRequired":true},{"name":"suspendedFlagAML","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagAML","columnRequired":false},{"name":"activityName","type":"string","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskSubject","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Name","columnRequired":true},{"name":"task","type":"string","content":"task","isArray":false,"sourceAttribute":"task","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Task","columnRequired":true},{"name":"planName","type":"string","content":"planName","isArray":false,"sourceAttribute":"planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityStartDate","type":"TIMESTAMP","content":"activityStartDate","isArray":false,"sourceAttribute":"activityStartDate","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Start Date/Time","columnRequired":true},{"name":"uwDecision","type":"string","content":"uwDecision","isArray":false,"sourceAttribute":"uwDecision","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"UW Decision ","columnRequired":true},{"name":"concurrentPolicyFlag","type":"BOOLEAN","content":"concurrentPolicyFlag","isArray":false,"sourceAttribute":"concurrentPolicyFlag","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"concurrentPolicyFlag","columnRequired":false}],
"items":[{"policyNumber":"'11111111'",
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,"activityStartDate":"2021-05-20T10:01:15Z","activityName":"Step: Non Med Task","freshCase":"Fresh","planCode":"planCode1","channel":"Channel1","uwDecision":null,"tsar":"10001","ape":"APE1","suspenseAmount":"100","planType":"PlanType1","owner":"NonMedUW1","premiumIndicator":"N","receivedDate":"2021-05-20T10:01:15Z","instanceId":"3139","taskId":"3312","planName":"PlanName","displayName":null,"savedAsDraftUW":false,"savedAsDraftAML":false,"flaggedAML":false,"paymentMethod":"paymentMethod1","flaggedUW":true,"due":"2020-10-18T08:23:36Z","priority":20,"remark":null,"suspendedFlagUW":true,"suspendedFlagAML":false,"task":"Channel1PlanType1null10001","concurrentPolicyFlag":true}]}}
        return res.status(200).send(data20);
    }else if(req.params.id == 30) {
        //m
        var data30 = {"status":"200","data":{"identifier":"TASK.TKIID","query":"NB_ClaimedAndAvailable","entityTypeName":"TASK","queryExecuteTime":"2021-05-24T07:23:30Z","taskIndexUpdateInterval":5,"offset":0,"size":3,"requestedSize":10000,"totalCount":3,"countLimitExceeded":false,"countLimit":500,"lowPriorityCnt":1,"midPriorityCnt":1,"highPriorityCnt":1,"attributeInfo":[{"name":"suspenseAmount","type":"string","content":"TASK.BDSUSPENSE_AMOUNT","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.suspenseAmount","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Suspense Amount","columnRequired":true},{"name":"policyNumber","type":"string","content":"TASK.BDPOLICY_NUMBER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.policyNumber","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Policy Number","columnRequired":true},{"name":"suspendedFlagUW","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagUW","columnRequired":false},{"name":"savedAsDraftUW","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftUW","columnRequired":false},{"name":"planName","type":"string","content":"TASK.BDPLAN_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"flaggedAML","type":"BOOLEAN","content":"TASK.BDFLAGGED_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedAML","columnRequired":false},{"name":"displayName","type":"string","content":"TASK.BDWORKFLOW_STATUS","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.workflowStatus","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Workflow Status","columnRequired":false},{"name":"planCode","type":"string","content":"TASK.BDPLAN_CODE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planCode","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Plan Code","columnRequired":true},{"name":"owner","type":"string","content":"TASK.OWNER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.assignedToUser","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Current User","columnRequired":true},{"name":"paymentMethod","type":"string","content":"TASK.BDPAYMENT_METHOD","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.paymentMethod","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Payment Method","columnRequired":false},{"name":"channel","type":"string","content":"TASK.BDCHANNEL","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.channel","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Channel","columnRequired":true},{"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskPriority","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Priority","columnRequired":false},{"name":"freshCase","type":"string","content":"TASK.BDFRESH_O_RR2_O_RCS_CASE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.freshORr2ORcsCase","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Fresh or R2 or c/s cases","columnRequired":true},{"name":"ape","type":"string","content":"TASK.BD_A_P_E","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.APE","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"APE","columnRequired":true},{"name":"receivedDate","type":"TIMESTAMP","content":"TASK.ACTIVATED","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskReceivedDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Received Date / Time","columnRequired":true},{"name":"planType","type":"string","content":"TASK.BDPLAN_TYPE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planType","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan type","columnRequired":true},{"name":"due","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskDueDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Task Due Date","columnRequired":false},{"name":"flaggedUW","type":"BOOLEAN","content":"TASK.BDFLAGGED_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedUW","columnRequired":false},{"name":"savedAsDraftAML","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftAML","columnRequired":false},{"name":"premiumIndicator","type":"string","content":"TASK.BDPREMIUM_INDICATOR","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.premiumIndicator","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Premium Indicator","columnRequired":true},{"name":"tsar","type":"string","content":"TASK.BD_T_S_A_R","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.TSAR","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"TSAR","columnRequired":true},{"name":"suspendedFlagAML","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagAML","columnRequired":false},{"name":"activityName","type":"string","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskSubject","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Name","columnRequired":true},{"name":"task","type":"string","content":"task","isArray":false,"sourceAttribute":"task","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Task","columnRequired":true},{"name":"planName","type":"string","content":"planName","isArray":false,"sourceAttribute":"planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityStartDate","type":"TIMESTAMP","content":"activityStartDate","isArray":false,"sourceAttribute":"activityStartDate","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Start Date/Time","columnRequired":true},{"name":"uwDecision","type":"string","content":"uwDecision","isArray":false,"sourceAttribute":"uwDecision","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"UW Decision ","columnRequired":true},{"name":"concurrentPolicyFlag","type":"BOOLEAN","content":"concurrentPolicyFlag","isArray":false,"sourceAttribute":"concurrentPolicyFlag","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"concurrentPolicyFlag","columnRequired":false}],
        items:[{"policyNumber":"'11111112'",
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,"activityStartDate":"2021-05-20T10:01:15Z","activityName":"Step: Non Med Task","freshCase":"Fresh","planCode":"planCode1","channel":"Channel1","uwDecision":null,"tsar":"10001","ape":"APE1","suspenseAmount":"100","planType":"PlanType1","owner":"NonMedUW1","premiumIndicator":"N","receivedDate":"2021-05-20T10:01:15Z","instanceId":"3139","taskId":"3312","planName":"PlanName","displayName":null,"savedAsDraftUW":false,"savedAsDraftAML":false,"flaggedAML":false,"paymentMethod":"paymentMethod1","flaggedUW":false,"due":"2020-10-18T08:23:36Z","priority":30,"remark":null,"suspendedFlagUW":true,"suspendedFlagAML":false,"task":"Channel1PlanType1null10001","concurrentPolicyFlag":null}]}}
        return res.status(200).send(data30);
    }else if(req.params.id == 40) {
        //L
        var data40 = {"status":"200","data":{"identifier":"TASK.TKIID","query":"NB_ClaimedAndAvailable","entityTypeName":"TASK","queryExecuteTime":"2021-05-24T07:23:30Z","taskIndexUpdateInterval":5,"offset":0,"size":3,"requestedSize":10000,"totalCount":3,"countLimitExceeded":false,"countLimit":500,"lowPriorityCnt":1,"midPriorityCnt":1,"highPriorityCnt":1,"attributeInfo":[{"name":"suspenseAmount","type":"string","content":"TASK.BDSUSPENSE_AMOUNT","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.suspenseAmount","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Suspense Amount","columnRequired":true},{"name":"policyNumber","type":"string","content":"TASK.BDPOLICY_NUMBER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.policyNumber","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Policy Number","columnRequired":true},{"name":"suspendedFlagUW","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagUW","columnRequired":false},{"name":"savedAsDraftUW","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftUW","columnRequired":false},{"name":"planName","type":"string","content":"TASK.BDPLAN_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"flaggedAML","type":"BOOLEAN","content":"TASK.BDFLAGGED_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedAML","columnRequired":false},{"name":"displayName","type":"string","content":"TASK.BDWORKFLOW_STATUS","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.workflowStatus","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Workflow Status","columnRequired":false},{"name":"planCode","type":"string","content":"TASK.BDPLAN_CODE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planCode","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Plan Code","columnRequired":true},{"name":"owner","type":"string","content":"TASK.OWNER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.assignedToUser","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Current User","columnRequired":true},{"name":"paymentMethod","type":"string","content":"TASK.BDPAYMENT_METHOD","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.paymentMethod","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Payment Method","columnRequired":false},{"name":"channel","type":"string","content":"TASK.BDCHANNEL","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.channel","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Channel","columnRequired":true},{"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskPriority","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Priority","columnRequired":false},{"name":"freshCase","type":"string","content":"TASK.BDFRESH_O_RR2_O_RCS_CASE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.freshORr2ORcsCase","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Fresh or R2 or c/s cases","columnRequired":true},{"name":"ape","type":"string","content":"TASK.BD_A_P_E","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.APE","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"APE","columnRequired":true},{"name":"receivedDate","type":"TIMESTAMP","content":"TASK.ACTIVATED","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskReceivedDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Received Date / Time","columnRequired":true},{"name":"planType","type":"string","content":"TASK.BDPLAN_TYPE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planType","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan type","columnRequired":true},{"name":"due","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskDueDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Task Due Date","columnRequired":false},{"name":"flaggedUW","type":"BOOLEAN","content":"TASK.BDFLAGGED_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedUW","columnRequired":false},{"name":"savedAsDraftAML","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftAML","columnRequired":false},{"name":"premiumIndicator","type":"string","content":"TASK.BDPREMIUM_INDICATOR","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.premiumIndicator","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Premium Indicator","columnRequired":true},{"name":"tsar","type":"string","content":"TASK.BD_T_S_A_R","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.TSAR","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"TSAR","columnRequired":true},{"name":"suspendedFlagAML","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagAML","columnRequired":false},{"name":"activityName","type":"string","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskSubject","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Name","columnRequired":true},{"name":"task","type":"string","content":"task","isArray":false,"sourceAttribute":"task","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Task","columnRequired":true},{"name":"planName","type":"string","content":"planName","isArray":false,"sourceAttribute":"planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityStartDate","type":"TIMESTAMP","content":"activityStartDate","isArray":false,"sourceAttribute":"activityStartDate","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Start Date/Time","columnRequired":true},{"name":"uwDecision","type":"string","content":"uwDecision","isArray":false,"sourceAttribute":"uwDecision","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"UW Decision ","columnRequired":true},{"name":"concurrentPolicyFlag","type":"BOOLEAN","content":"concurrentPolicyFlag","isArray":false,"sourceAttribute":"concurrentPolicyFlag","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"concurrentPolicyFlag","columnRequired":false}],
"items":[{"policyNumber":"'11111113'",
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,"activityStartDate":"2021-05-20T10:01:15Z","activityName":"Step: Non Med Task","freshCase":"Fresh","planCode":"planCode1","channel":"Channel1","uwDecision":null,"tsar":"10001","ape":"APE1","suspenseAmount":"100","planType":"PlanType1","owner":"NonMedUW1","premiumIndicator":"N","receivedDate":"2021-05-20T10:01:15Z","instanceId":"3139","taskId":"3312","planName":"PlanName","displayName":null,"savedAsDraftUW":false,"savedAsDraftAML":false,"flaggedAML":false,"paymentMethod":"paymentMethod1","flaggedUW":false,"due":"2020-10-18T08:23:36Z","priority":40,"remark":null,"suspendedFlagUW":true,"suspendedFlagAML":false,"task":"Channel1PlanType1null10001","concurrentPolicyFlag":true}]}}
        return res.status(200).send(data40);
    }
    
 });
 var usepref = {
	"userPreferences":
		{"fullName":"NonMedUW1","role":"NonMedUWmanager","groupName":"NB_NonMedUW","userId":"1010","users":["NonMedUW1","NonMedUW2"],
			"savedQueries":[
				{
					"queryName":"abc",
					"queryValue":[
						{"columnName":"planCode","value":"testing","operation":"=","join":"and","type":"string"},
						{"columnName":"planType","value":"testing1","operation":"=","join":null,"type":"string"},
					]
				}
			]
		}
	};
 router.get('/api/userpreference/:id', function (req, res) {
    return res.status(200).send(usepref)
    
 });
router.post('/api/login', function (req, res) {
   return res.status(200).send({"success":true,"accessToken":"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI1ZjZlNTA3M2EzYzUzYjA5NzAwNjU1NzUiLCJpYXQiOjE2MDI0MTUwMjcsImV4cCI6MTYwMjQxNTYyNywiYXVkIjoiaHR0cDovL3NhbWEuaW8vIiwiaXNzIjoiU0FNQSBiYWNrZW5kIiwic3ViIjoiZGV2MUBzYW1hLmlvIn0.IKyKikk5YiX7TCBXfvjjwvo4ySqxbXe6EMKMmc-_6UwVsNt6GhGqtwu4Xh5Ng5CNnsJxgDL6p8Wch26jlimQpr6k4vFXxrny3RGQad17MtenJOL3D8_Ax_7N4gmXOuo2V-V3FYah1jLdA1_WxEidEShTfBDejfqQBBkTcOI4HrVEv8SBxy91ks_yGq08JJhugiZpc_glWz-neR-r3LseYN80FCAVPZFAxituAc7Y8Y5bIMGPtkZcOmOHTK2pR3gPDXPUaDL_evgZk0sMU3G_iUg0i98qoRtzDRZSN1zVq7A2_m5omrFCbeKx-Cf3kGVlSTjjnzyyMzcsPh1aeCk6XgXpkeltWSjv9MHsIxCMe2FQfY5FHoXldmlmS59toerwA-CFi8JX92pfsvKFeI1B2P0Xer4xj7zJrhNH3GRTL6WvRFPxaNhlhUkvoJIopqpEPPquGNb5RH1CJr9UMlZ8amB0Gn1Yx8B47WVrGB77UEDqKYZ26QtUTDbJ8hw2D0c51XG85s-KD2fxJ4d8HjJdyGF8L9rwIAspqKCnVPBOc6lCvOkOmhZQLMQIxQ9h2M-fOFqAbDN2Iyp00XA_NmQaFIAcXGOMArgYd6NE5zLElK913pvMiyNWJe1lcO7w3HLwl4HL8WGNfFoGZsntnAv0IUF39lslm-qwvJlGFd5Sy7U","refreshToken":"4nWscjLa4wqgylZjsoMrY7BpNcZNw2mWNbY28A0ww3ff86oUqy0Kvrp3mzibrsPbNqOqTEfyLV493moK6NyaDzghZbKTkOlruyTdRtx1AbkyaAPOEvXS0iESi5i79o6KdgqiYcaZzgPzPe1yhoOfwKSKmSLryV9Kxc3QcuLiqsiDVs1aRzjk41obeL1QEP7nb5KVmq5pM6gAW0KYvdfYdnTD4qvf4RYKx2ecBmlbRicPrqBeBb64sAkEvzNAyL"});
});
router.put('/api/tasklist/flagOrUnSuspend/:flag', function (req, res) {
    return res.status(200).send(data);
 });
 router.get('/api/tasklist/concurrentpolicy/:processId', function (req, res) {
    return res.status(200).send([
        {
            "proposalNumber":"1234",
            "creationDate":"03/07/2021",
            "laName":"Robin",
            "proposalStatus":"In force",
            "plan":"PruShield"
        },{
            "proposalNumber":"1234",
            "creationDate":"03/07/2021",
            "laName":"Robin",
            "proposalStatus":"In force",
            "plan":"PruShield"
        },{
            "proposalNumber":"1234",
            "creationDate":"03/07/2021",
            "laName":"Robin",
            "proposalStatus":"In force",
            "plan":"PruShield"
        }
    ]);
 });
// advanced query search
 router.post('/api/tasklist/advancesearch', function (req, res) {
    return res.status(200).send({errorCode:"500", errorMessage:"danger"});
 });
 //suspended
 // advanced query search
 router.get('/api/tasklist/NB_ClaimedAndSuspended', function (req, res) {
     var data2 = {"status":"200","data":{"identifier":"TASK.TKIID","query":"NB_ClaimedAndAvailable","entityTypeName":"TASK","queryExecuteTime":"2021-05-24T07:23:30Z","taskIndexUpdateInterval":5,"offset":0,"size":3,"requestedSize":10000,"totalCount":3,"countLimitExceeded":false,"countLimit":500,"lowPriorityCnt":1,"midPriorityCnt":1,"highPriorityCnt":1,"attributeInfo":[{"name":"suspenseAmount","type":"string","content":"TASK.BDSUSPENSE_AMOUNT","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.suspenseAmount","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Suspense Amount","columnRequired":true},{"name":"policyNumber","type":"string","content":"TASK.BDPOLICY_NUMBER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.policyNumber","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Policy Number","columnRequired":true},{"name":"suspendedFlagUW","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagUW","columnRequired":false},{"name":"savedAsDraftUW","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftUW","columnRequired":false},{"name":"planName","type":"string","content":"TASK.BDPLAN_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"flaggedAML","type":"BOOLEAN","content":"TASK.BDFLAGGED_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedAML","columnRequired":false},{"name":"displayName","type":"string","content":"TASK.BDWORKFLOW_STATUS","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.workflowStatus","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Workflow Status","columnRequired":false},{"name":"planCode","type":"string","content":"TASK.BDPLAN_CODE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planCode","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Plan Code","columnRequired":true},{"name":"owner","type":"string","content":"TASK.OWNER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.assignedToUser","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Current User","columnRequired":true},{"name":"paymentMethod","type":"string","content":"TASK.BDPAYMENT_METHOD","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.paymentMethod","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Payment Method","columnRequired":false},{"name":"channel","type":"string","content":"TASK.BDCHANNEL","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.channel","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Channel","columnRequired":true},{"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskPriority","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Priority","columnRequired":false},{"name":"freshCase","type":"string","content":"TASK.BDFRESH_O_RR2_O_RCS_CASE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.freshORr2ORcsCase","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Fresh or R2 or c/s cases","columnRequired":true},{"name":"ape","type":"string","content":"TASK.BD_A_P_E","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.APE","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"APE","columnRequired":true},{"name":"receivedDate","type":"TIMESTAMP","content":"TASK.ACTIVATED","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskReceivedDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Received Date / Time","columnRequired":true},{"name":"planType","type":"string","content":"TASK.BDPLAN_TYPE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planType","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan type","columnRequired":true},{"name":"due","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskDueDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Task Due Date","columnRequired":false},{"name":"flaggedUW","type":"BOOLEAN","content":"TASK.BDFLAGGED_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedUW","columnRequired":false},{"name":"savedAsDraftAML","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftAML","columnRequired":false},{"name":"premiumIndicator","type":"string","content":"TASK.BDPREMIUM_INDICATOR","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.premiumIndicator","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Premium Indicator","columnRequired":true},{"name":"tsar","type":"string","content":"TASK.BD_T_S_A_R","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.TSAR","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"TSAR","columnRequired":true},{"name":"suspendedFlagAML","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagAML","columnRequired":false},{"name":"activityName","type":"string","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskSubject","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Name","columnRequired":true},{"name":"task","type":"string","content":"task","isArray":false,"sourceAttribute":"task","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Task","columnRequired":true},{"name":"planName","type":"string","content":"planName","isArray":false,"sourceAttribute":"planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityStartDate","type":"TIMESTAMP","content":"activityStartDate","isArray":false,"sourceAttribute":"activityStartDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Activity Start Date/Time","columnRequired":true},{"name":"uwDecision","type":"string","content":"uwDecision","isArray":false,"sourceAttribute":"uwDecision","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"UW Decision ","columnRequired":true},{"name":"concurrentPolicyFlag","type":"BOOLEAN","content":"concurrentPolicyFlag","isArray":false,"sourceAttribute":"concurrentPolicyFlag","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"concurrentPolicyFlag","columnRequired":false}],"items":[]}}
    return res.status(200).send(data2);
 });

 //save or edit or delete search query
 router.put('/api/userpreference/:id', function (req, res) {
	 var obj = {};
	 obj['queryName'] =req.body.queryName;
	 obj['queryValue'] =req.body.queryValue;
	 usepref.userPreferences.savedQueries.push(obj)
    return res.status(200).send({statusCode:"200", errorMessage:"succsss"});
 });
 //save or edit or delete search query
 router.get('/api/tasklist/freetextsearch', function (req, res) {
    return res.status(200).send({"status":"200","data":{"identifier":"TASK.TKIID","query":"NB_ClaimedAndAvailable","entityTypeName":"TASK","queryExecuteTime":"2021-05-24T07:26:13Z","taskIndexUpdateInterval":5,"offset":0,"size":1,"requestedSize":10000,"totalCount":1,"countLimitExceeded":false,"countLimit":500,"lowPriorityCnt":0,"midPriorityCnt":0,"highPriorityCnt":0,"attributeInfo":[{"name":"flaggedAML","type":"BOOLEAN","content":"TASK.BDFLAGGED_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedAML","columnRequired":false},{"name":"planType","type":"string","content":"TASK.BDPLAN_TYPE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planType","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan type","columnRequired":true},{"name":"displayName","type":"string","content":"TASK.BDWORKFLOW_STATUS","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.workflowStatus","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Workflow Status","columnRequired":false},{"name":"suspendedFlagUW","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagUW","columnRequired":false},{"name":"suspenseAmount","type":"string","content":"TASK.BDSUSPENSE_AMOUNT","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.suspenseAmount","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Suspense Amount","columnRequired":true},{"name":"savedAsDraftAML","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftAML","columnRequired":false},{"name":"freshCase","type":"string","content":"TASK.BDFRESH_O_RR2_O_RCS_CASE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.freshORr2ORcsCase","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Fresh or R2 or c/s cases","columnRequired":true},{"name":"owner","type":"string","content":"TASK.OWNER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.assignedToUser","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Current User","columnRequired":true},{"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskPriority","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Priority","columnRequired":false},{"name":"policyNumber","type":"string","content":"TASK.BDPOLICY_NUMBER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.policyNumber","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Policy Number","columnRequired":true},{"name":"receivedDate","type":"TIMESTAMP","content":"TASK.ACTIVATED","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskReceivedDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Received Date / Time","columnRequired":true},{"name":"premiumIndicator","type":"string","content":"TASK.BDPREMIUM_INDICATOR","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.premiumIndicator","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Premium Indicator","columnRequired":true},{"name":"ape","type":"string","content":"TASK.BD_A_P_E","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.APE","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"APE","columnRequired":true},{"name":"flaggedUW","type":"BOOLEAN","content":"TASK.BDFLAGGED_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedUW","columnRequired":false},{"name":"planCode","type":"string","content":"TASK.BDPLAN_CODE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planCode","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Plan Code","columnRequired":true},{"name":"tsar","type":"string","content":"TASK.BD_T_S_A_R","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.TSAR","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"TSAR","columnRequired":true},{"name":"savedAsDraftUW","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftUW","columnRequired":false},{"name":"due","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskDueDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Task Due Date","columnRequired":false},{"name":"paymentMethod","type":"string","content":"TASK.BDPAYMENT_METHOD","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.paymentMethod","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Payment Method","columnRequired":false},{"name":"suspendedFlagAML","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagAML","columnRequired":false},{"name":"channel","type":"string","content":"TASK.BDCHANNEL","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.channel","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Channel","columnRequired":true},{"name":"planName","type":"string","content":"TASK.BDPLAN_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityName","type":"string","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskSubject","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Name","columnRequired":true},{"name":"task","type":"string","content":"task","isArray":false,"sourceAttribute":"task","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Task","columnRequired":true},{"name":"planName","type":"string","content":"planName","isArray":false,"sourceAttribute":"planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityStartDate","type":"TIMESTAMP","content":"activityStartDate","isArray":false,"sourceAttribute":"activityStartDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Activity Start Date/Time","columnRequired":true},{"name":"uwDecision","type":"string","content":"uwDecision","isArray":false,"sourceAttribute":"uwDecision","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"UW Decision ","columnRequired":true},{"name":"concurrentPolicyFlag","type":"BOOLEAN","content":"concurrentPolicyFlag","isArray":false,"sourceAttribute":"concurrentPolicyFlag","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"concurrentPolicyFlag","columnRequired":false}],"items":[{"policyNumber":"'11111111'",
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,"activityStartDate":"2021-05-20T10:01:15Z","activityName":"Step: Non Med Task","freshCase":"Fresh","planCode":"planCode1","channel":"Channel1","uwDecision":null,"tsar":"10001","ape":"APE1","suspenseAmount":"100","planType":"PlanType1","owner":"NonMedUW1","premiumIndicator":"N","receivedDate":"2021-05-20T10:01:15Z","instanceId":"3139","taskId":"3312","planName":"PlanName","displayName":null,"savedAsDraftUW":false,"savedAsDraftAML":false,"flaggedAML":false,"paymentMethod":"paymentMethod1","flaggedUW":false,"due":"2020-10-18T08:23:36Z","priority":10,"remark":null,"suspendedFlagUW":true,"suspendedFlagAML":false,"task":"Channel1PlanType1null10001","concurrentPolicyFlag":null}]}})
 });
 //save or edit or delete search query
 router.get('/api/tasklist/sort', function (req, res) {
    return res.status(200).send({"status":"200","data":{"identifier":"TASK.TKIID","query":"NB_ClaimedAndAvailable","entityTypeName":"TASK","queryExecuteTime":"2021-05-24T07:26:13Z","taskIndexUpdateInterval":5,"offset":0,"size":1,"requestedSize":10000,"totalCount":1,"countLimitExceeded":false,"countLimit":500,"lowPriorityCnt":0,"midPriorityCnt":0,"highPriorityCnt":0,"attributeInfo":[{"name":"flaggedAML","type":"BOOLEAN","content":"TASK.BDFLAGGED_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedAML","columnRequired":false},{"name":"planType","type":"string","content":"TASK.BDPLAN_TYPE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planType","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan type","columnRequired":true},{"name":"displayName","type":"string","content":"TASK.BDWORKFLOW_STATUS","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.workflowStatus","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Workflow Status","columnRequired":false},{"name":"suspendedFlagUW","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagUW","columnRequired":false},{"name":"suspenseAmount","type":"string","content":"TASK.BDSUSPENSE_AMOUNT","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.suspenseAmount","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Suspense Amount","columnRequired":true},{"name":"savedAsDraftAML","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftAML","columnRequired":false},{"name":"freshCase","type":"string","content":"TASK.BDFRESH_O_RR2_O_RCS_CASE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.freshORr2ORcsCase","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Fresh or R2 or c/s cases","columnRequired":true},{"name":"owner","type":"string","content":"TASK.OWNER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.assignedToUser","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Current User","columnRequired":true},{"name":"priority","type":"NUMBER","content":"TASK.PRIORITY","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskPriority","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Priority","columnRequired":false},{"name":"policyNumber","type":"string","content":"TASK.BDPOLICY_NUMBER","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.policyNumber","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Policy Number","columnRequired":true},{"name":"receivedDate","type":"TIMESTAMP","content":"TASK.ACTIVATED","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskReceivedDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Received Date / Time","columnRequired":true},{"name":"premiumIndicator","type":"string","content":"TASK.BDPREMIUM_INDICATOR","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.premiumIndicator","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Premium Indicator","columnRequired":true},{"name":"ape","type":"string","content":"TASK.BD_A_P_E","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.APE","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"APE","columnRequired":true},{"name":"flaggedUW","type":"BOOLEAN","content":"TASK.BDFLAGGED_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.flaggedUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"flaggedUW","columnRequired":false},{"name":"planCode","type":"string","content":"TASK.BDPLAN_CODE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planCode","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Plan Code","columnRequired":true},{"name":"tsar","type":"string","content":"TASK.BD_T_S_A_R","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.TSAR","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"TSAR","columnRequired":true},{"name":"savedAsDraftUW","type":"BOOLEAN","content":"TASK.BDSAVED_AS_DRAFT_U_W","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.savedAsDraftUW","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"savedAsDraftUW","columnRequired":false},{"name":"due","type":"TIMESTAMP","content":"TASK.DUE","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskDueDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Task Due Date","columnRequired":false},{"name":"paymentMethod","type":"string","content":"TASK.BDPAYMENT_METHOD","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.paymentMethod","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Payment Method","columnRequired":false},{"name":"suspendedFlagAML","type":"BOOLEAN","content":"TASK.BDPARKED_CASE_FLAG_A_M_L","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.parkedCaseFlagAML","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"suspendedFlagAML","columnRequired":false},{"name":"channel","type":"string","content":"TASK.BDCHANNEL","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.channel","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Channel","columnRequired":true},{"name":"planName","type":"string","content":"TASK.BDPLAN_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityName","type":"string","content":"TASK_DESC.DISPLAY_NAME","isArray":false,"sourceAttribute":"NB_ClaimedAndAvailable.taskSubject","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Activity Name","columnRequired":true},{"name":"task","type":"string","content":"task","isArray":false,"sourceAttribute":"task","sourceQueryTableIdentifier":"n/a","hidden":false,"field":"Task","columnRequired":true},{"name":"planName","type":"string","content":"planName","isArray":false,"sourceAttribute":"planName","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Plan Name","columnRequired":false},{"name":"activityStartDate","type":"TIMESTAMP","content":"activityStartDate","isArray":false,"sourceAttribute":"activityStartDate","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"Activity Start Date/Time","columnRequired":true},{"name":"uwDecision","type":"string","content":"uwDecision","isArray":false,"sourceAttribute":"uwDecision","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"UW Decision ","columnRequired":true},{"name":"concurrentPolicyFlag","type":"BOOLEAN","content":"concurrentPolicyFlag","isArray":false,"sourceAttribute":"concurrentPolicyFlag","sourceQueryTableIdentifier":"n/a","hidden":true,"field":"concurrentPolicyFlag","columnRequired":false}],"items":[{"policyNumber":"'11111111'",
			"parkedCaseFlagUW": true,
			"parkedCaseFlagAML": false,"activityStartDate":"2021-05-20T10:01:15Z","activityName":"Step: Non Med Task","freshCase":"Fresh","planCode":"planCode1","channel":"Channel1","uwDecision":null,"tsar":"10001","ape":"APE1","suspenseAmount":"100","planType":"PlanType1","owner":"NonMedUW1","premiumIndicator":"N","receivedDate":"2021-05-20T10:01:15Z","instanceId":"3139","taskId":"3312","planName":"PlanName","displayName":null,"savedAsDraftUW":false,"savedAsDraftAML":false,"flaggedAML":false,"paymentMethod":"paymentMethod1","flaggedUW":false,"due":"2020-10-18T08:23:36Z","priority":10,"remark":null,"suspendedFlagUW":true,"suspendedFlagAML":false,"task":"Channel1PlanType1null10001","concurrentPolicyFlag":null}]}})
 });
 
 router.put('/api/tasklist/reassign', function (req, res) {
    return res.status(500).send({statusCode:"500", errorMessage:"There is some database issue"});
 });
 router.get('/newbusiness/propsaldetails/header/:id', function (req, res) {
    return res.status(200).send({
      policyNumber: req.params.id,
      plan: 'PruActive Life',
      contractType: 'PM1',
      adminId: 'MikeD',
      businessSource: 'banca',
      proposalDate: '6/9/2020',
      proposalReceivedDate: '6/9/2020',
      uwDecision: 'decision',
      uwId: '7465',
      fcName: 'bin hashim',
      fcCode: '0160',
      fcMobileNo: '+65 123345',
      fcEmailAddress: 'te@st.com',
      fcResidentialAddress: 'blc no 2 loy hayat',
      proposerName: 'abdul halim',
      jointProposerName: 'Joshua',
      mainLifeAssured: 'shen',
      secLifeAssured: 'benjamin',
      premiumStatus: 'Proposal',
      validationsErrors: 'sample error'
    });
 });
 router.get('/newbusiness/propsaldetails/followupcode/:id', function (req, res) {
    return res.status(200).send([{"followUpCode":"2","lf":"1","jl":"00","status":"L","reminderDate":"12/4/2021","createdDate":"12/4/2021","remarks":"NB - AL (RP/SP)","addressTo":"A","cltAgtNo":"01568","encInd":"","extendedText":"null","createdBy":"SVIDCHAN:367279:Vidhya Chandrasek","modifiedBy":"SVIDCHAN:367279:Vidhya Chandrasek","modifiedDate":"12/4/2021"},{"followUpCode":"3","lf":"1","jl":"00","status":"E","reminderDate":"12/4/2021","createdDate":"12/4/2021","remarks":"NB-EXPIRE DATE (10)","addressTo":"A","cltAgtNo":"01568","encInd":"","extendedText":"null","createdBy":"SVIDCHAN:367279:Vidhya Chandrasek","modifiedBy":"SVIDCHAN:367279:Vidhya Chandrasek","modifiedDate":"12/4/2021"}]);
 });
 router.get('/newbusiness/propsaldetails/underwriting/:id', function (req, res) {
    return res.status(200).send({"preIssueProposalValidation":null,"uwComments":null,"uwDecision":{"inceptionDate":"19/8/2015","pruExtraEffectiveDate":"0/0/0","communicationToFC":"  "},"pmr":null,"planComponent":null,"exclusionNotes":[{"exclusionCode":"P082","exclusionCodeDesc":"Ankylosing Spondylitis"},{"exclusionCode":"P129","exclusionCodeDesc":"Anaemia"}]});
 });
module.exports = router